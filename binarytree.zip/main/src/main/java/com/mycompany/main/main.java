public class BinaryNode {
    int data; // данные, хранимые в узле
    BinaryNode left; // ссылка на левого потомка
    BinaryNode right; // ссылка на правого потомка

    // Конструктор узла
    public BinaryNode(int data) {
        this.data = data;
        this.left = null;
        this.right = null;
    }
}

public class BinarySearchTree {
    private BinaryNode root; // корень дерева

    // Конструктор дерева
    public BinarySearchTree() {
        this.root = null;
    }

    // Метод для вставки элемента в дерево
    public void insert(int data) {
        root = insertRec(root, data);
    }

    // Рекурсивный метод для вставки элемента
    private BinaryNode insertRec(BinaryNode root, int data) {
        if (root == null) {
            root = new BinaryNode(data);
            return root;
        }

        if (data < root.data) {
            root.left = insertRec(root.left, data);
        } else if (data > root.data) {
            root.right = insertRec(root.right, data);
        }

        return root;
    }

    // Метод для обхода дерева в порядке возрастания (inorder)
    public void inorder() {
        inorderRec(root);
    }

    // Рекурсивный метод для обхода дерева в порядке возрастания
    private void inorderRec(BinaryNode root) {
        if (root != null) {
            inorderRec(root.left);
            System.out.print(root.data + " ");
            inorderRec(root.right);
        }
    }
}
